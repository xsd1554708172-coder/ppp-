# FINAL MANUSCRIPT PATCH

本文档给出将 `PPP_empirical_reinforcement_bundle_20260416_unified_v3` 整合进论文终稿的最终替换方案。所有补充识别与稳健性检验均以 `treat_share` 多期 DID/TWFE 为唯一主识别前提，不改变主论文结构。

## 1. 摘要

- 原位置：摘要主结果段，基准 DID 主发现之后。
- 应新增内容：采用 `abstract_final_patch.md` 中的一句话。
- 关联输出：
  - `04_manuscript_integration/abstract_final_patch.md`
- 注意事项：
  - 不要把趋势调整型 DID 或 leave-one-province-out 写成新主模型；
  - 不要把 `ppp_quality_zindex` 写成已经被补充检验证实的主结论。

## 2. 第5章 5.3 结尾承接句

- 原位置：事件研究小节结尾。
- 应新增内容：

  “基于上述动态路径与识别边界，后文进一步采用趋势调整型 DID 与逐省剔除诊断，对推进结构结果在更严格趋势设定和样本扰动下的稳定性进行防守性检验。”

- 关联输出：
  - `04_manuscript_integration/section_5_6_final.md`

## 3. 第5章 5.6 全节替换

- 原位置：现有 5.6 “稳健性检验”全节。
- 应删除内容：
  - 任何将多种补充方法平铺并列、未区分层级的段落；
  - 任何将 stack DID、cohort ATT、动态补充识别写成主防守层的表述；
  - 任何将 event study 写成“平行趋势成立”的说法。
- 应替换内容：
  - 用 `section_5_6_final.md` 整段替换。
- 关联输出：
  - `04_manuscript_integration/section_5_6_final.md`
- 注意事项：
  - 5.6.1 只对应趋势调整型 DID；
  - 5.6.2 只对应 leave-one-province-out；
  - 5.6.3 只保留更保守推断的短段；
  - 5.6.4 必须保持简述，不展开系数细节。

## 4. 结论与讨论

- 原位置：结论部分关于稳健性和研究边界的段落。
- 应新增内容：采用 `conclusion_final_patch.md` 中的一句话。
- 关联输出：
  - `04_manuscript_integration/conclusion_final_patch.md`
- 注意事项：
  - 结论中继续保持“推进结构改善优先”的主线；
  - 不要借补充识别层抬高质量型结果。

## 5. 表格与图注更新

- 原位置：图 8A、图 8B、稳健性摘要表及相关表注。
- 应替换内容：采用 `notes/table_figure_caption_notes.md` 中的 caption 与 note。
- 关联输出：
  - `01_trend_adjusted_DID/figures/Figure_8A_trend_adjusted_did_20260417_1537.(png|svg)`
  - `02_leave_one_province_out_jackknife/figures/Figure_8B_jackknife_stability_20260417_1537.(png|svg)`
  - `04_manuscript_integration/tables/robustness_defense_summary.xlsx`
  - `04_manuscript_integration/notes/table_figure_caption_notes.md`

## 6. 编号与更新顺序

- 推荐顺序：
  1. 先替换 5.3 结尾承接句；
  2. 再整段替换 5.6；
  3. 插入图 8A、图 8B 与稳健性摘要表；
  4. 最后补摘要和结论中的一句话。
- 关联说明：
  - `04_manuscript_integration/notes/manuscript_update_map.md`
