# Manuscript update map

## Manuscript anchor

- File:
  - `PPP论文_完整论文初稿_公共管理风格_修订版_定点替换_20260415.docx`
- Inspection status:
  - actual `.docx` inspected via document XML extraction
  - section 5.6 confirmed as the robustness block that needs structural replacement

## Required updates

1. 摘要
   - add one sentence from `abstract_final_patch.md`

2. 第5章 5.3 结尾
   - add one transition sentence leading from dynamic-path limitations to defensive robustness

3. 第5章 5.6
   - replace current robustness section with `section_5_6_final.md`
   - structure fixed as:
     - 5.6.1 趋势调整型防守检验
     - 5.6.2 单一地区驱动风险诊断
     - 5.6.3 更保守推断下的边界说明
     - 5.6.4 其他补充识别结果（简述）

4. 图表
   - use timestamped paper versions of Figure 8A and Figure 8B
   - insert `robustness_defense_summary.xlsx` as the manuscript-facing summary table
   - apply captions/notes from `table_figure_caption_notes.md`

5. 结论
   - add one sentence from `conclusion_final_patch.md`

## Integration boundary

- Main identification remains Table 4 (`treat_share` DID/TWFE)
- Figure 8A and Figure 8B are defensive layers
- small-sample inference remains short boundary support
- stack DID / cohort ATT / dynamic supplementary identification remain downgraded diagnostics
